tar -cvzf shellbackup.tar.gz dir1 dir2 dir3
ls
git add shellbackup.tar.gz
git commit -m 'shell backup'
git push origin master
echo "Done"
